export interface Activity {
  "Activityid": string;
  "Name": string;
  "Type": string;
  "Location": string;
  "Price": string;
  "Price Category": string;
}